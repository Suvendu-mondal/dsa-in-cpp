// solve it using Tortoise Algo (slow/fast approach)
// check it on leetcode